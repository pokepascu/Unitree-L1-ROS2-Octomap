# Unitree 4D LiDAR L1 — ROS 2 Humble

Environnement reproductible pour compiler, lancer, contrôler et enregistrer les
données du Unitree 4D LiDAR L1 sous ROS 2 Humble, sans installer ROS sur l’hôte
Ubuntu 24.04.

## État actuel

- Hôte inventorié : Ubuntu 24.04.2 LTS, `x86_64`.
- Docker et Docker Compose opérationnels.
- Environnement cible : Ubuntu 22.04 Jammy + ROS 2 Humble dans Docker.
- SDK Unitree figé : `v1.0.16`, commit
  `1bd7d95d8ab7ce7a22058d2bb07e39fd62612aa6`.
- Image Humble construite et pilote compilé contre PCL 1.12 sans patch fournisseur.
- Paquet `l1_monitor` compilé et testé : diagnostics cloud/IMU sur `/diagnostics`.
- X11, accélération OpenGL et démarrage contrôlé de RViz2 validés sans capteur.
- LiDAR non requis pour la préparation et la compilation.
- Validation matérielle à venir via l’adaptateur série USB Unitree.

## Architecture

```text
Ubuntu 24.04 (hôte)
└── Docker Ubuntu 22.04 + ROS 2 Humble
    └── ros2_ws
        ├── unilidar_sdk (source fournisseur non modifiée)
        └── l1_bringup (lancement configurable du projet)
```

Le Compose principal fonctionne sans LiDAR. Le fichier
`docker/compose.lidar.yaml` ajoute explicitement le périphérique série seulement
lorsqu’il a été identifié sur l’hôte.

## Préparation

```bash
cd ~/unitree_l1_project
./scripts/docker-build.sh
./scripts/fetch-dependencies.sh
./scripts/workspace-build.sh
./scripts/smoke-test.sh
```

`workspace-build.sh` vérifie aussi automatiquement la présence et le commit du SDK.

Pour ouvrir un shell Humble :

```bash
./scripts/docker-shell.sh
```

Pour tester l’accès X11 avant RViz2 :

```bash
./scripts/gui-smoke-test.sh
```

Les commandes matérielles ne doivent être utilisées qu’après identification du
périphérique avec `./scripts/check-lidar.sh`.

## Lorsque le L1 sera connecté

La procédure complète et les précautions électriques sont dans
`docs/hardware-runbook.md`. Le chemin nominal est :

```bash
./scripts/check-lidar.sh
START_RVIZ=false ./scripts/lidar-launch.sh
# Dans un second terminal :
./scripts/lidar-validate.sh
```

Après validation des messages, relancer avec `START_RVIZ=true`, puis enregistrer
un essai borné :

```bash
BAG_LABEL=validation BAG_DURATION_SEC=30 ./scripts/record-bag.sh
```

## Documentation et traçabilité

- `docs/configuration-log.md` : chronologie des commandes et résultats.
- `docs/decisions.md` : choix techniques et justification.
- `docs/versions-lock.md` : versions, commits et digests.
- `docs/validation-matrix.md` : critères de test et verdicts.
- `docs/sources.md` : sources officielles consultées.
- `docs/hardware-runbook.md` : branchement, lancement, validation, bag et rejeu.
- `docs/report/synthese_pre_materiel.pdf` : synthèse A4 de trois pages.
- `scripts/build-synthesis-pdf.sh` : reconstruction locale de cette synthèse.
- `docs/archive/` : traces historiques conservées sans réécriture.

Le rapport PDF final sera produit à partir de ces preuves après validation du
LiDAR, du rosbag2 et de la cartographie.
