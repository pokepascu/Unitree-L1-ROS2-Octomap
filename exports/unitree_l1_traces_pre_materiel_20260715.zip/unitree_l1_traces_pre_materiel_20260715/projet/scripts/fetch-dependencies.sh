#!/usr/bin/env bash
set -euo pipefail

project_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export HOST_UID="$(id -u)"
export HOST_GID="$(id -g)"

docker compose -f "${project_root}/docker/compose.yaml" run --rm dev \
  bash -lc 'set -euo pipefail
    expected=1bd7d95d8ab7ce7a22058d2bb07e39fd62612aa6
    target=/workspace/ros2_ws/src/unilidar_sdk
    if [[ -d "${target}/.git" ]]; then
      actual="$(git -C "${target}" rev-parse HEAD)"
      if [[ "${actual}" != "${expected}" ]]; then
        printf "Unexpected Unitree commit: %s (expected %s)\n" "${actual}" "${expected}" >&2
        exit 1
      fi
      printf "Unitree dependency already present at %s\n" "${actual}"
    elif [[ -e "${target}" ]]; then
      printf "Target exists but is not a Git checkout: %s\n" "${target}" >&2
      exit 1
    else
      vcs import /workspace/ros2_ws/src < /workspace/config/dependencies.repos
      actual="$(git -C "${target}" rev-parse HEAD)"
      [[ "${actual}" = "${expected}" ]]
      printf "Unitree dependency imported at %s\n" "${actual}"
    fi'
