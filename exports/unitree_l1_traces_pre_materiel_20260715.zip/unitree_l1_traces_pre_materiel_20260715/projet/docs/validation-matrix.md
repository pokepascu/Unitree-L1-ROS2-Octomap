# Matrice de validation

| ID | Exigence | Commande / méthode | Attendu | Verdict |
|---|---|---|---|---|
| TST-001 | Construction depuis les fichiers figés | `./scripts/docker-build.sh` | build sans erreur | PASS 2026-07-15, rc 0 |
| TST-002 | Ubuntu Jammy | `/etc/os-release` dans l’image | 22.04 | PASS |
| TST-003 | ROS 2 Humble | `$ROS_DISTRO`, `ros2` | Humble disponible | PASS |
| TST-004 | Outils ROS | `colcon`, `rosdep`, `rviz2` | commandes présentes | PASS |
| TST-005 | Pilote Unitree | `./scripts/workspace-build.sh` | compilation Humble/PCL réussie | PASS, 3 paquets |
| TST-006 | Lancement configurable | `./scripts/smoke-test.sh` | port et options exposés | PASS, rc 0 |
| TST-007 | X11/DRI | `./scripts/gui-smoke-test.sh` | X11 et rendu direct | PASS, Intel/OpenGL 4.6 |
| TST-008 | RViz2 | démarrage contrôlé 8 s | fenêtre initialisée sans erreur | PASS, timeout 124 attendu |
| TST-009 | Périphérique L1 | `check-lidar.sh` | port série stable | BLOCKED_HW |
| TST-010 | Topics cloud/IMU | inspection ROS 2 | messages cohérents | BLOCKED_HW |
| TST-011 | Rosbag2 | enregistrement/rejeu | données reproductibles | BLOCKED_HW |
| TST-012 | Point-LIO/carte | bag puis PCD | trajectoire/carte cohérentes | BLOCKED_HW |
| TST-013 | ABI du pilote | `readelf`, `ldd`, symboles GLIBCXX | aucune dépendance absente | PASS |
| TST-014 | Tests projet | `colcon test` et `test-result` | 0 échec | PASS, 8/8 |
| TST-015 | Graphe sans capteur | launch sur port absent | nœud/topics/paramètres observables | PASS_CONTRACT_ONLY |
| TST-016 | Arrêt du pilote | timeout SIGINT direct | arrêt avant SIGKILL | PASS, ~1,1 s |
| TST-017 | Alarme sans données | `/diagnostics` après timeout | cloud et IMU en ERROR | PASS |
| TST-018 | Moniteur synthétique | publishers 10/30 Hz | deux diagnostics sains | PASS |
| TST-019 | Refus sans périphérique | `lidar-launch.sh` sans L1 | arrêt avant Docker | PASS, rc 2 attendu |
| TST-020 | Intégrité fournisseur | commit et `git status` vendor | commit attendu, dépôt propre | PASS |
| TST-021 | Style Python ROS 2 | `ament_flake8`, `ament_pep257` | aucun problème | PASS, 13 fichiers |

`PASS_CONTRACT_ONLY` confirme uniquement le contrat ROS statique. Le nœud Unitree
peut rester vivant et déclarer ses publishers après un échec série ; TST-010 ne
passera qu'après réception de messages réels. Le paquet fournisseur ne définit
aucun test CTest ; les 8 tests comptés appartiennent à `l1_monitor` et
`l1_bringup`.
