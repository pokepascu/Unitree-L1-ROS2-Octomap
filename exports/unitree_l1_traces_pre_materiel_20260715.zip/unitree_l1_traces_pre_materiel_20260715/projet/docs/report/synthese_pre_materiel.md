# Synthèse du jalon logiciel — Unitree 4D LiDAR L1

Date : 15 juillet 2026

Statut : environnement logiciel validé avant branchement du LiDAR

## Objectif et résultat

L'objectif était de préparer un environnement reproductible pour compiler,
lancer, surveiller, visualiser et enregistrer les données du Unitree 4D LiDAR L1
avec ROS 2 Humble, sans installer ROS ni modifier la configuration logicielle de
l'ordinateur hôte.

La préparation logicielle est terminée et validée sans capteur :

- Ubuntu 24.04.2 reste intact sur l'hôte ;
- Docker fournit Ubuntu 22.04 Jammy et ROS 2 Humble ;
- le SDK Unitree est figé sur `v1.0.16`, commit
  `1bd7d95d8ab7ce7a22058d2bb07e39fd62612aa6` ;
- le pilote compile avec PCL 1.12.1 sans modification du fournisseur ;
- `l1_bringup` rend le port, les topics, les frames, RViz et le moniteur
  configurables ;
- `l1_monitor` contrôle fréquences, âge, timestamps, frames, nombre de points et
  champs, puis publie `/diagnostics` ;
- les scripts de détection, lancement, validation, rosbag2 et rejeu sont prêts.

Le LiDAR n'était pas connecté pendant ce jalon. Aucune donnée physique de nuage de
points ou d'IMU n'est donc encore validée.

## Architecture

```text
Ubuntu 24.04.2 — ordinateur hôte intact
└── Docker
    └── Ubuntu 22.04 + ROS 2 Humble
        └── workspace ROS 2
            ├── unitree_lidar_ros2 — pilote fournisseur intact
            ├── l1_bringup — lancement et paramètres du projet
            └── l1_monitor — surveillance cloud/IMU
```

Image projet : `unitree-l1:humble-v1.0.16`

ID : `sha256:60dfcef73d6c3cd6efbb4842c946f25305ff460d8e9f9c8d1fdd8976a346de64`

## Versions et preuves principales

| Élément | Version validée |
|---|---|
| ROS 2 / Ubuntu conteneur | Humble / 22.04 Jammy |
| GCC / CMake / Python | 11.4.0 / 3.22.1 / 3.10.12 |
| PCL / Eigen / Boost | 1.12.1 / 3.4.0 / 1.74 |
| RViz2 / Mesa | 11.2.27 / 23.2.1 |
| colcon / rosdep / vcstool | 0.21.0 / 0.26.0 / 0.3.0 |

Le binaire pilote mesure 1 554 464 octets. Son SHA-256 est
`c7ed1cf9d632bb7cf04b95018a0395819578816fc81a821ac241e3278cbb61b0`.
L'audit ne relève aucune bibliothèque absente et confirme la compatibilité de
l'archive fournisseur GCC 9.4 avec le runtime GCC 11.4.

Résultats :

- build initial : 2 paquets en 21,0 s ;
- build final : 3 paquets en 2,84 s ;
- tests : 8 réussis sur 8, aucun échec ;
- linters : 13 fichiers Python, aucun problème ;
- test synthétique : cloud proche de 10 Hz, IMU proche de 30 Hz ;
- alarme sans données : deux statuts ERROR correctement émis ;
- RViz2 actif 8 secondes avec rendu direct Intel/OpenGL 4.6 ;
- matrice : 16 PASS, 1 validation de contrat et 4 validations bloquées par le
  matériel.

## Contrat ROS préparé

| Flux | Type | Repère |
|---|---|---|
| `/unilidar/cloud` | `sensor_msgs/msg/PointCloud2` | `unilidar_lidar` |
| `/unilidar/imu` | `sensor_msgs/msg/Imu` | `unilidar_imu` |
| `/diagnostics` | `diagnostic_msgs/msg/DiagnosticArray` | surveillance |

Le QoS est Reliable, Volatile, KeepLast(10).

## Précautions appliquées

- aucun ROS installé sur l'hôte ;
- aucun conteneur privilégié et aucun `chmod 777` ;
- vendor Unitree intact et figé par commit ;
- périphérique série ajouté seulement après identification ;
- X11 en lecture seule et accès graphique limité à `/dev/dri` ;
- aucune désactivation préventive de ModemManager ;
- Point-LIO différé jusqu'à l'obtention d'un rosbag réel.

## Limites actuelles

Ne sont pas encore démontrés : port série réel, permissions USB, messages cloud et
IMU, fréquences et timestamps réels, champs et unités, qualité du nuage, rosbag2,
extrinsèques, Point-LIO, trajectoire et carte 3D.

La présence du nœud ou de ses publishers n'est pas une preuve de fonctionnement :
le pilote peut rester actif après un échec série. Il ne publie pas de TF et ne
demande pas explicitement les modes `NORMAL` au démarrage ou `STANDBY` à l'arrêt.

## Prochaine étape

1. Immobiliser le L1 et utiliser l'adaptateur Unitree avec une alimentation
   séparée 12 V / 1 A.
2. Respecter le TTL 3,3 V et 2 000 000 bit/s.
3. Identifier le port : `./scripts/check-lidar.sh`.
4. Lancer sans RViz : `START_RVIZ=false ./scripts/lidar-launch.sh`.
5. Dans un second terminal : `./scripts/lidar-validate.sh`.

Le premier verdict matériel exigera un message cloud, un message IMU, une
fréquence non nulle pour chacun et un message `/diagnostics`. Ensuite viendront
RViz2, un bag de 30 secondes, le rejeu, Point-LIO, la carte et le rapport PDF final.

## Où trouver les preuves

- `docs/configuration-log.md` : chronologie et incidents ;
- `logs/commands/` : registre des commandes ;
- `logs/builds/` et `logs/tests/` : journaux bruts ;
- `docs/validation-matrix.md` : verdicts ;
- `docs/versions-lock.md` : versions et hashes ;
- `docs/hardware-runbook.md` : procédure matérielle détaillée.

Le jalon logiciel de référence est le commit Git `24a6876`.
