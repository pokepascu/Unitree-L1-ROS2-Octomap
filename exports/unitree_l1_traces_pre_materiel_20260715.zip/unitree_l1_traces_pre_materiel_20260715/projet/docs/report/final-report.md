# Rapport final — Unitree 4D LiDAR L1 sous ROS 2 Humble

Statut : squelette préparé ; ne pas exporter comme rapport final avant que tous
les critères matériels obligatoires soient validés.

## 1. Résumé exécutif

- Objectif et résultat final.
- Architecture hôte Noble / Docker Jammy-Humble.
- Versions, commit et date du jalon reproductible.

## 2. Matériel et sécurité

- Modèle/numéro de série, câbles, adaptateur et alimentation.
- Port stable, VID/PID, permissions et éventuelles règles ciblées.
- Conditions physiques de chaque essai.

## 3. Installation et reconstruction

- Inventaire initial.
- Dockerfile, Compose headless/GUI/LiDAR.
- SDK figé, dépendances, build et sourcing.

## 4. Incidents, corrections et raisons

- Reprendre chaque entrée `ERR-*` du journal.
- Distinguer erreur de commande, avertissement sans impact et défaut fournisseur.
- Expliquer les solutions rejetées et leurs risques.

## 5. Pilote et contrat ROS 2

- Paramètres série, topics, types, QoS et frames.
- ABI, comportement d'initialisation/arrêt et limites connues.
- Résultats réels avec le L1.

## 6. Validation des données 4D

- Fréquences, latence/âge, timestamps et continuité.
- Point count, champs PointCloud2, intensité, unités et repères.
- IMU immobile puis mouvements contrôlés.
- Captures RViz2 et diagnostics `l1_monitor`.

## 7. Rosbag2

- Nom, scène, durée, taille, topics et compteurs.
- Rejeu, comparaison des fréquences et hash des métadonnées/données.

## 8. Point-LIO et carte 3D

- Dépôt/commit sélectionné après inspection du bag.
- Adaptations de topics, champs, timestamps et extrinsèques.
- Trajectoire, dérive, boucles, paramètres et incidents.
- Export PCD, contrôles géométriques et hash.

## 9. Reproduction par un tiers

- Recette depuis un clone propre.
- Commandes exactes et temps observés.
- Limites liées aux paquets APT non figés octet pour octet.

## 10. Conclusion et travaux futurs

- Critères satisfaits et réserves.
- Intégration Jackal explicitement hors de cette première étape.

## Annexes

- Journal chronologique.
- Registre des décisions et matrice de validation.
- Manifeste des versions et hashes.
- Sources officielles.
