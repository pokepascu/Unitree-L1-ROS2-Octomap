# Journal de configuration — Unitree L1

Ce journal est chronologique. Il conserve les commandes, buts, effets, résultats,
erreurs, corrections et validations nécessaires au futur rapport PDF.

L’ancien journal issu d’un environnement restreint est conservé intact dans
`docs/archive/configuration-log.initial-incorrect.20260715.md` avec le SHA-256
`fa834c17d0f520e59fac194f00d9c591d160ee79c14d4049680d95e0bb2b35f8`.
Ses observations invalidées ne servent pas de référence hôte.

## LOG-20260715-001 — Lecture du dossier fourni

- Phase : P0 — cadrage.
- Type : inspection.
- Statut : SUCCÈS.
- But : lire la synthèse PDF fournie et sa feuille de route. L'agent n'a pas un
  accès séparé à une autre conversation ; le document est la source de continuité.
- Commandes :

```bash
pdfinfo dossier_configuration_unitree_l1_ros2.pdf
pdftotext -layout dossier_configuration_unitree_l1_ros2.pdf -
```

- Résultat : document de 11 pages lu intégralement ; phases P0 à P7, contraintes
  de sécurité et livrables identifiés.
- Effet : aucun fichier système modifié.

## LOG-20260715-002 — Inventaire direct de l’hôte

- Phase : P0 — inventaire.
- Type : inspection.
- Statut : SUCCÈS.
- But : établir l’état réel du PC avant installation.
- Commandes principales :

```bash
lsb_release -a
uname -a
lscpu
free -h
df -hT
lspci -nnk
nvidia-smi
ip -brief link
ip -brief address
ip route
lsusb
lsusb -t
docker version
docker info
docker compose version
git --version
command -v gcc g++ make cmake colcon ros2 python3 pip3 rviz2
```

- Résultat : Ubuntu 24.04.2 LTS, noyau 6.17.0-35, x86_64, Intel i7-5500U,
  15 Gio de RAM, 850 Gio libres, Docker 29.6.1 et Compose 5.3.1 fonctionnels.
- Outils hôte : Git 2.43.0, Make 4.3 et Python 3.12.3 présents ; GCC, G++, CMake,
  colcon et ROS 2 absents.
- Matériel : aucun `ttyUSB*`/`ttyACM*` Unitree ; Ethernet sans porteuse.
- Décision : ne rien installer sur l’hôte ; compiler dans Docker Jammy/Humble.

## ERR-20260715-001 — Invalidations du journal préliminaire

- Statut : CORRIGÉ.
- Cause : les premières commandes avaient été exécutées dans un contexte restreint
  qui masquait des composants de l’hôte.
- Corrections démontrées :

| Observation initiale | Observation directe corrigée |
|---|---|
| Ubuntu Core 24 | Ubuntu 24.04.2 LTS Noble classique |
| Docker absent | Docker client/serveur 29.6.1 opérationnel |
| Compose inconnu | Docker Compose 5.3.1 |
| `lsusb` absent | `/usr/bin/lsusb` présent |
| Make absent | GNU Make 4.3 présent |
| espace disque ambigu | `/dev/sda2`, environ 850 Gio libres |

L’archive n’a pas été supprimée ni réécrite.

## LOG-20260715-003 — Vérification Docker existant

- Statut : SUCCÈS.
- Commandes : `docker ps -a`, `docker images --digests`, `docker system df`,
  `docker compose version`, `docker buildx version`.
- Résultat : un ancien environnement `ros2_ws:foxy` existe et reste hors périmètre ;
  aucun conteneur existant n’a été démarré, arrêté ou supprimé par l’agent principal.
- Décision : créer une image distincte `unitree-l1:humble-v1.0.16`.

## LOG-20260715-004 — Sources officielles et interface matérielle

- Statut : SUCCÈS.
- Résultat : le chemin standard Unitree est UART TTL 3,3 V à 2 000 000 bit/s vers
  l’adaptateur fourni, puis USB série, avec alimentation séparée 12 V/1 A.
- Conséquence : aucun adressage IP ni réseau hôte n’est requis pour le pilote série.
- Compatibilité : le fournisseur documente Foxy/PCL 1.10 ; Humble/PCL 1.12 doit être
  validé par compilation et tests locaux.

## LOG-20260715-005 — Création de la structure du projet

- Type : modification locale réversible.
- Statut : SUCCÈS.
- Commandes :

```bash
mkdir -p docker ros2_ws/src config launch scripts bags maps logs docs/records docs/references
git init
git branch -m main
```

- Résultat : arborescence créée sous `/home/isr/unitree_l1_project`, dépôt Git local
  initialisé sans publication ni commit.

## LOG-20260715-006 — Image de base ROS figée

- Statut : SUCCÈS.
- Commande :

```bash
docker buildx imagetools inspect ros:humble-ros-base-jammy
```

- Résultat amd64 : digest
  `sha256:5c793b92e0b12d6babb438cb20eed7766495fde6419a21e3d2e918464f09dc17`.
- Justification : éviter qu’un tag mutable change silencieusement la base du build.

## LOG-20260715-007 — SDK Unitree figé

- Statut : SUCCÈS.
- Commande :

```bash
git clone --branch v1.0.16 --depth 1 \
  https://github.com/unitreerobotics/unilidar_sdk.git \
  ros2_ws/src/unilidar_sdk
git -C ros2_ws/src/unilidar_sdk rev-parse HEAD
git -C ros2_ws/src/unilidar_sdk describe --tags --exact-match
```

- Résultat : tag `v1.0.16`, commit
  `1bd7d95d8ab7ce7a22058d2bb07e39fd62612aa6`, dépôt propre.
- Précaution : le vendor est exclu du dépôt parent et recréable via
  `config/dependencies.repos`.

## LOG-20260715-008 — Fichiers reproductibles initiaux

- Type : modification locale réversible.
- Statut : SUCCÈS.
- But : préparer Docker, Compose, scripts, configurations et traces sans LiDAR.
- Fichiers affectés : `README.md`, `AGENTS.md`, `.gitignore`, `.dockerignore`,
  `docker/`, `scripts/`, `config/` et `docs/`.
- Précautions : pas de `privileged`, pas de `chmod 777`, pas de ROS hôte, pas de
  périphérique obligatoire dans le Compose principal, cookie X11 monté en lecture
  seule et jamais journalisé.

## LOG-20260715-009 — Paquet de lancement configurable

- Type : développement projet.
- Statut : SUCCÈS, build et launch validés.
- But : éviter de modifier le `launch.py` fournisseur qui fixe `/dev/ttyUSB0`.
- Résultat : paquet `l1_bringup` avec arguments `port`, `cloud_topic`, `imu_topic`,
  `cloud_frame`, `imu_frame` et `rviz` ; paramètres Unitree originaux conservés.
- Effet matériel : aucun ; le launch ne sera pas exécuté avant la compilation.

## ERR-20260715-002 — Exclusion logique du paquet ROS 1

- Statut : CORRIGÉ AVANT EXÉCUTION.
- Symptôme anticipé : un `rosdep`/`colcon` global découvrirait aussi
  `unilidar_sdk/unitree_lidar_ros`, qui utilise ROS 1 `catkin`.
- Correction : limiter `--from-paths` et `--base-paths` au pilote ROS 2 et à
  `l1_bringup`.
- Justification : ne pas altérer le dépôt fournisseur avec un `COLCON_IGNORE`.

## ERR-20260715-003 — Cohérence du port et reconstruction des dépendances

- Statut : CORRIGÉ AVANT TEST MATÉRIEL.
- Problème 1 : l’override Compose expose `/dev/unitree_lidar` alors que le launch
  utilisait encore `/dev/ttyUSB0` par défaut.
- Correction 1 : la valeur par défaut du launch lit désormais `LIDAR_PORT`, avec
  repli sur `/dev/ttyUSB0` hors override.
- Problème 2 : le manifeste `dependencies.repos` n’était pas encore consommé.
- Correction 2 : `fetch-dependencies.sh` importe le SDK si absent et refuse de
  continuer si son commit ne correspond pas au verrou attendu.

## LOG-20260715-010 — Construction de l'image Humble

- Type : modification Docker locale ; aucune installation sur l'hôte.
- Statut : SUCCÈS.
- Commande : `./scripts/docker-build.sh`.
- Durée observée : environ 16 min 14 s au premier build.
- Résultat : image `unitree-l1:humble-v1.0.16`, ID
  `sha256:60dfcef73d6c3cd6efbb4842c946f25305ff460d8e9f9c8d1fdd8976a346de64`.
- Environnement obtenu : Ubuntu 22.04, ROS 2 Humble, GCC/G++ 11.4.0,
  CMake 3.22.1, Python 3.10.12, PCL 1.12.1 et RViz2 11.2.27.
- Taille affichée par Docker : 4,04 Go d'usage disque, contenu 914 Mo.

## ERR-20260715-004 — Détection de version PCL par `pkg-config`

- Statut : CORRIGÉ.
- Commande initiale : `pkg-config --modversion pcl_common`.
- Symptôme : aucun fichier `pcl_common.pc` n'est fourni par le paquet Jammy.
- Correction : lecture par `dpkg-query -W libpcl-dev` et
  `PCLConfigVersion.cmake` ; version confirmée : `1.12.1`.
- Conclusion : défaut de la méthode de contrôle, pas de l'image Docker.

## ERR-20260715-005 — Expansion prématurée dans une requête `dpkg`

- Statut : CORRIGÉ.
- Symptôme : `${Package}` a été interprété par le shell avec `set -u` avant
  d'être transmis à `dpkg-query`.
- Correction : utiliser la sortie par défaut de `dpkg-query` sans format contenant
  une expansion shell.
- Effet : aucun changement système ; simple commande de lecture relancée.

## ERR-20260715-006 — Ordre de chargement ROS et mode `nounset`

- Statut : CORRIGÉ.
- Symptôme : lors d'un diagnostic éphémère, `set -u` exécuté avant
  `source /opt/ros/humble/setup.bash` a provoqué
  `AMENT_TRACE_SETUP_FILES: unbound variable`.
- Correction : sourcer ROS avant d'activer `nounset`, ou laisser l'entrypoint de
  l'image sourcer ROS avant le script.
- Effet : aucun défaut de l'image et aucun fichier du projet modifié par l'essai.

## ERR-20260715-007 — Clés sans définition `rosdep` exploitable

- Statut : CORRIGÉ POUR LE BUILD.
- Symptôme : `rosdep check` signale les clés `ament_python` dans `l1_bringup` et
  `pcl` dans le manifeste fournisseur, bien que les composants requis soient déjà
  installés dans l'image.
- Vérification : une simulation avec
  `--skip-keys "ament_python pcl"` termine avec le code 0 et ne propose aucun
  paquet supplémentaire.
- Correction : le script de build ignore explicitement ces deux clés seulement ;
  toutes les autres dépendances restent contrôlées par `rosdep`.

## LOG-20260715-011 — Compilation Humble/PCL du pilote

- Phase : P2 — pilote.
- Statut : SUCCÈS.
- Commande : `./scripts/workspace-build.sh`.
- Résultat initial : code 0, `unitree_lidar_ros2` puis `l1_bringup`, 2 paquets en
  21,0 s ; édition de liens du binaire Unitree réussie avec PCL 1.12.
- Résultat final après ajout du moniteur : code 0, 3 paquets en 2,84 s.
- Preuves : `logs/builds/20260715-initial-colcon-build.log` et
  `logs/builds/20260715-final-colcon-build.log`.
- Intégrité : aucun patch dans `unilidar_sdk`, commit fournisseur toujours propre.

## ERR-20260715-008 — Avertissement CMake fournisseur CMP0074

- Statut : ACCEPTÉ, NON BLOQUANT.
- Sortie : `find_package(PCL)` ignore `PCL_ROOT=/usr` car la politique CMP0074
  n'est pas fixée par le CMake fournisseur.
- Résultat : CMake trouve PCL 1.12, compile et lie le binaire ; aucune correction
  vendor n'est nécessaire. L'avertissement reste visible dans la preuve brute.

## LOG-20260715-012 — Audit ABI et liaison du binaire

- Statut : SUCCÈS.
- Commandes principales : `readelf`, `strings`, `nm`, `ldd`, `sha256sum` dans
  l'image Humble ou sur le binaire de build.
- Résultats : ELF64 PIE x86_64, 1 554 464 octets, SHA-256
  `c7ed1cf9d632bb7cf04b95018a0395819578816fc81a821ac241e3278cbb61b0`.
- `ldd` : aucune bibliothèque manquante. La bibliothèque Unitree est incorporée
  statiquement ; son symbole `createUnitreeLidarReader()` est présent.
- ABI : archive compilée avec GCC 9.4, nœud avec GCC 11.4 ; GLIBCXX requis au plus
  3.4.29 et runtime disponible jusqu'à 3.4.30.
- Archive x86_64 : SHA-256
  `295efc9d55192483c66be291fe74ba0c3795c049c5e5286f650c6e7cf2d79cdf`.

## ERR-20260715-009 — Utilitaire `file` absent dans l'image minimale

- Statut : CORRIGÉ.
- Symptôme : première commande d'identification ELF, code 127, car `file` n'est
  pas installé dans l'image minimale.
- Correction : utiliser `readelf`, déjà disponible via la chaîne de compilation.
- Décision : ne pas agrandir l'image pour un utilitaire de diagnostic remplaçable.

## LOG-20260715-013 — Audit auxiliaire de référence Foxy

- Statut : TERMINÉ ET NETTOYÉ ; résultat non utilisé comme validation matérielle.
- Démarche : clone d'audit sous `/tmp`, tentative CMake hôte (code 127, CMake
  absent), puis build éphémère Foxy dans Docker : 1 paquet réussi en ~22,8 s.
- Essai sans port : nœud vivant sous timeout 124 attendu, aucune donnée.
- Incident : deux conteneurs temporaires se sont brièvement chevauchés ; un
  `Publisher count: 2` observé alors est invalidé et ne sert à aucune conclusion.
- Nettoyage : conteneurs temporaires arrêtés/supprimés, aucun vendor du projet
  modifié. Un pull auxiliaire du tag mutable `ros:humble-ros-base-jammy` a aussi
  ajouté l'image locale `sha256:afb40d6…`; elle ne remplace pas le digest amd64
  `sha256:5c793b9…` explicitement figé dans le Dockerfile.

## LOG-20260715-014 — Contrat ROS sans capteur

- Statut : SUCCÈS POUR LE CONTRAT, PAS POUR LE MATÉRIEL.
- Méthode : lancement isolé sur domaine ROS 187 avec
  `LIDAR_PORT=/dev/unitree_absent_audit`.
- Résultat : `/unitree_lidar_ros2_node` vivant ; un publisher
  `/unilidar/cloud` de type `sensor_msgs/msg/PointCloud2` et un publisher
  `/unilidar/imu` de type `sensor_msgs/msg/Imu` ; port paramétré correctement.
- QoS observé : Reliable, Volatile, liveliness Automatic ; KeepLast(10) confirmé
  dans le source, bien que la profondeur soit affichée `UNKNOWN` par ros2cli.
- Données : `ros2 topic echo --once` expire après 3 s, code 124 et 0 octet, comme
  attendu sans L1. Les logs signalent le port inexistant puis
  `Unilidar is not initialized!`.
- Conclusion : la présence du nœud et des publishers n'est jamais un healthcheck
  matériel, car le retour de `initialize()` est ignoré par le pilote.

## ERR-20260715-010 — Harnais d'arrêt du launch

- Statut : CORRIGÉ.
- Symptôme : SIGINT adressé au processus launch en arrière-plan n'a pas été
  propagé de façon fiable ; TERM après 3 s, code launch 143.
- Correction : tester directement l'ELF avec un timeout envoyant SIGINT ; le
  gestionnaire rclcpp apparaît et le processus sort environ 1,1 s plus tard,
  avant le SIGKILL de garde.
- Interprétation : latence cohérente avec `runParse()` bloquant ; premier verdict
  d'arrêt gracieux du harnais invalidé, test direct retenu.

## LOG-20260715-015 — Paquet `l1_monitor`

- Phase : P4 — surveillance.
- Statut : SUCCÈS SANS MATÉRIEL.
- Fichiers : paquet Python `ros2_ws/src/l1_monitor`, paramètres dans
  `l1_bringup/config/unitree_l1.yaml`, démarrage par défaut dans le launch.
- Fonction : fréquence d'arrivée, âge, timestamps non croissants ou nuls, frame,
  nombre de points et champs ; deux statuts publiés sur `/diagnostics`.
- QoS : Reliable/Volatile/KeepLast(10), aligné avec le pilote.
- Seuils provisoires : rapport 2 s, timeout 3 s, âge 1 s, cloud 5 Hz, IMU 20 Hz,
  fenêtre de 100 messages. Ils seront validés sur les flux réels.

## ERR-20260715-011 — Nettoyage du premier test moniteur en arrière-plan

- Statut : CORRIGÉ ET NETTOYÉ.
- Symptôme : le processus Python en arrière-plan avait hérité d'un SIGINT ignoré ;
  le trap attendait indéfiniment.
- Correction : suppression forcée du seul conteneur éphémère
  `unitree-l1-dev-run-60b5b6c62f02` (code final 137), puis harnais borné par TERM
  et KILL de garde. Aucun processus n'est resté actif.
- Validation séparée : exécution avant-plan 4 s, timeout 124 attendu, alarmes
  `no messages received` émises toutes les 0,5 s.

## ERR-20260715-012 — Sérialisation du niveau DiagnosticStatus

- Statut : CORRIGÉ.
- Symptôme : le premier grep cherchait `level: 2`, tandis que ros2cli affiche
  l'octet ERROR sous la forme `level: "\\x02"`; la commande fonctionnelle a donc
  terminé avec code 1 après avoir reçu le bon message.
- Correction : assertion sur la représentation octet et sur les deux textes
  `no messages received`.
- Résultat : `MONITOR_NO_DATA_ALARM_PASS`, code 0.

## LOG-20260715-016 — Tests du code projet et moniteur synthétique

- Statut : SUCCÈS.
- Commande : `colcon test --packages-select l1_monitor l1_bringup
  unitree_lidar_ros2`, puis `colcon test-result --all --verbose`.
- Résultat final : 3 tests statistiques, 1 test du launch et 4 tests de lint
  intégrés, soit 8/8, 0 erreur, 0 échec, 0 ignoré. Le paquet fournisseur ne
  fournit aucun CTest.
- Preuves : `logs/tests/20260715-final-colcon-test.log` et
  `logs/tests/20260715-final-colcon-test-result.log`.
- Test DDS synthétique : PointCloud2 à ~10 Hz, Imu à ~30 Hz, frames attendues,
  quatre points et champs x/y/z ; deux diagnostics `stream healthy`, code 0,
  `MONITOR_SYNTHETIC_HEALTH_PASS`.

## LOG-20260715-017 — X11, DRI et RViz2

- Statut : SUCCÈS.
- Commandes : `./scripts/gui-smoke-test.sh`, puis démarrage de RViz2 sous timeout
  SIGINT de 8 s avec le profil projet.
- Résultat : `xdpyinfo` réussi, rendu direct accéléré Intel HD Graphics 5500,
  Mesa 23.2.1, OpenGL 4.6 ; RViz reste actif 8 s puis s'arrête au signal.
- Code RViz : 124 attendu du timeout, harnais global code 0.
- Profil : `/unilidar/cloud`, Fixed Frame et Target Frame `unilidar_lidar`.

## ERR-20260715-013 — RViz sans accès DRM initial

- Statut : CORRIGÉ.
- Symptôme initial : RViz fonctionnait 8 s et annonçait OpenGL 4.5, mais Mesa ne
  pouvait pas ouvrir `/dev/dri/card1` et utilisait un repli graphique.
- Correction : déplacer X11/DRI dans `compose.gui.yaml`, ajouter seulement
  `/dev/dri` et les GID video/render, garder `compose.yaml` headless.
- Résultat : rendu direct Intel/OpenGL 4.6, plus d'erreur DRI au test final.
- Avertissement restant : `Stereo is NOT SUPPORTED`, informatif et sans impact.

## LOG-20260715-018 — Scripts matériels et runbook

- Statut : PRÊTS, NON EXÉCUTÉS SUR MATÉRIEL.
- Fichiers : `check-lidar.sh`, `lidar-launch.sh`, `lidar-validate.sh`,
  `record-bag.sh`, `bag-info.sh`, `replay-bag.sh` et
  `docs/hardware-runbook.md`.
- Sécurité : vrai tty résolu avec `readlink -e`, GID lu avec `stat -L`, refus des
  ports inattendus/occupés, un seul device Compose, pas de privileged/chmod 777,
  pas d'arrêt automatique de ModemManager.
- Contrôle sans L1 : 0 candidat détecté ; `lidar-launch.sh` refuse avant Docker,
  code 2 attendu et `LIDAR_ABSENT_REFUSAL_PASS`.
- État hôte observé : ModemManager 1.23.4 actif/activé ; `brltty` installé mais
  inactif/désactivé. Aucune configuration de ces services n'a été changée.

## LOG-20260715-019 — Conservation du dossier d'entrée et des preuves

- Statut : SUCCÈS.
- PDF copié sans conversion dans
  `docs/references/dossier_configuration_unitree_l1_ros2.pdf`.
- Métadonnées : titre « Projet Unitree 4D LiDAR L1 sous ROS 2 Humble », Pascual,
  11 pages A4, 108 212 octets, création PDF 15 juillet 2026 15:11:24 WEST.
- SHA-256 :
  `848185726cf4899efac63df62cfdef21985ec3b042eec9e52ae26113b5b84661`.
- Hashes des logs bruts :
  - build initial : `6f54f2197b21c352d535eefd9bd1954b5d79f75afb014049c0dc56b9c0eab2b6` ;
  - build final : `127859e73be1e24af7886efaccfac6a274000f7d0877bc3c1dc7c6c176d8b014` ;
  - tests : `30355dad29b2912bfedb59f7a3e330dede7ad19002f9edc847332316e218172c` ;
  - résultat tests : `66d6208d839956313fd9decb8031f46f18e2f6671f3ff9ecdd743a3ffa6f566a`.

## LOG-20260715-020 — Limites connues avant branchement

- Le pilote ignore le code de retour de `initialize()` et peut rester vivant sans
  données ; le moniteur, pas le graphe seul, doit constater les flux.
- Le destructeur fournisseur est vide, `runParse()` est bloquant et aucun TF n'est
  publié.
- Le pilote ROS 2 n'appelle explicitement ni le mode `NORMAL` au démarrage ni
  `STANDBY` à l'arrêt. Ce point sera qualifié sans patch au premier essai.
- Les frames, champs, timestamps, fréquences, unités, IMU, permissions réelles,
  rosbag2, extrinsèques, Point-LIO et carte restent `BLOCKED_HW`.
- Décision : ne pas sélectionner/adapter Point-LIO avant d'avoir un bag court
  contenant les messages réels du L1.

## LOG-20260715-021 — Archivage du manuel Unitree officiel

- Statut : SUCCÈS.
- Commande : téléchargement HTTPS depuis le CDN officiel, copie locale inchangée,
  contrôle par `pdfinfo`, `pdftotext` et `sha256sum`.
- Fichier : `docs/references/unitree_l1_user_manual.pdf`, 18 pages A4,
  1 163 168 octets, SHA-256
  `4d816cdf6197a51c5e87e6e7876da822b2d0e52e0bf63df306b40ac32fb13a74`.
- Vérifications documentaires : p. 3 (11 Hz azimutal, IMU reportée à 250 Hz),
  p. 7 (12 V et RX/TX 3,3 V), p. 11 (adaptateur, alimentation et câble fournis),
  p. 15 (12 V/1 A), p. 16 (TTL UART, 2 000 000 bit/s).

## LOG-20260715-022 — Linters ROS 2 du code projet

- Statut : SUCCÈS.
- Commandes : `ament_flake8 src/l1_monitor src/l1_bringup` et
  `ament_pep257 src/l1_monitor src/l1_bringup` dans l'image Humble.
- Résultat : 13 fichiers Python contrôlés, aucun problème de style ou docstring,
  code 0 pour les deux outils.
- Avertissement de test : l'outillage ament/Humble utilise encore l'ancienne
  interface `SelectableGroups` de `importlib_metadata` ; quatre warnings au total,
  sans erreur de lint ni effet sur le code projet.

## LOG-20260715-023 — Jalon Git avant matériel

- Statut : SUCCÈS.
- Configuration : identité Git définie uniquement dans ce dépôt comme
  `Codex <codex@localhost>` ; aucune configuration globale changée.
- Commandes : `git add --all`, contrôle de la liste indexée, puis
  `git commit -m 'Prepare and validate Unitree L1 Humble environment'`.
- Résultat : commit racine local
  `a844ba737bc8775bff97ea2263adfc2a26ee3c71`, 66 fichiers et 4 453 lignes
  ajoutées. Aucune publication distante.
- Portée : ce commit est la référence logicielle validée avant connexion du L1 ;
  le présent ajout documentaire sera son commit fils.

## ERR-20260715-014 — Chaîne PDF disponible sur l'hôte

- Statut : CORRIGÉ SANS INSTALLATION.
- Inventaire : Pandoc, LibreOffice, WeasyPrint, ReportLab et le device PDF direct
  de groff sont absents ; `groff -Tpdf` échoue faute de fichier `DESC`, et les
  macros `-ms` ne sont pas installées.
- Correction : source roff autonome, sortie PostScript par `groff -Kutf8 -Tps`,
  puis conversion A4 par Ghostscript `ps2pdf`.
- Justification : aucune installation hôte, accents français conservés et chaîne
  de génération versionnée dans le projet.

## ERR-20260715-015 — Premier rendu de la synthèse

- Statut : CORRIGÉ.
- Problème 1 : le suffixe roff `m` signifie « em » et non millimètre ; une largeur
  de ligne excessive plaçait le titre et une partie du texte hors page.
- Problème 2 : les tableaux `tbl` avec bordure produisaient un fond noir persistant
  dans le rendu Ghostscript.
- Problème 3 : les commandes commençant par `./` étaient interprétées comme des
  requêtes roff, et disparaissaient du PDF.
- Problème 4 : `pdftotext | grep -q` sous `pipefail` pouvait terminer la validation
  sur SIGPIPE après une correspondance pourtant correcte.
- Corrections : dimensions en centimètres, tableaux texte sans bordure, préfixe
  shell `$` devant les commandes et validation via un fichier texte temporaire.

## LOG-20260715-024 — PDF de synthèse avant matériel

- Statut : SUCCÈS.
- Commande : `./scripts/build-synthesis-pdf.sh`.
- Fichiers : source lisible Markdown, source de mise en page roff et PDF sous
  `docs/report/`.
- Résultat : 3 pages A4, PDF 1.4, texte français extractible, commandes matérielles
  présentes, pagination correcte ; les trois pages ont été rendues en PNG et
  inspectées visuellement.
- SHA-256 :
  `6ae9f7bb0ce5fa17f6e98c26f09e8f5b151a0241277337b9477f8ebcd2f6db8f`.
- Portée : résumé rapide du jalon logiciel, pas le rapport final après cartographie.
